from dataclasses import dataclass

from .formula import Formula

