from dataclasses import dataclass
from enum import Enum

from .substance import Substance
from .constant import SPECIFIC_HEAT_CONSTANT


class Phase(Enum):
    GAS = 0
    LIQUID = 1
    SOLID = 2
    AQUA = 3
    G = 0
    L = 1
    S = 2
    AQ = 3


@dataclass(frozen=True, eq=False)
class PhaseSubstance:
    substance: Substance
    phase: Phase

    phase_energy: float = 0.0  # J/mol

    density: float = 1.0  # g/cm**3
    specific_heat: float = SPECIFIC_HEAT_CONSTANT  # J/(mol*K)
    heat_transfer_coefficient: float = 1.0  # W/(m**2*K)
    surface_area_multiplier: float = 1.0
    external_surface_area_multiplier: float = 6.0

    @property
    def relative_mass(self):
        return self.substance.relative_mass

    @property
    def chemical_energy(self):
        return self.substance.chemical_energy
