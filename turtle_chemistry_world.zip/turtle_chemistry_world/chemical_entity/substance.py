from dataclasses import dataclass

from .formula import Formula


@dataclass(frozen=True, eq=False)
class Substance:
    """纯净物，表示一种物质分子共有特性的类
    即一个Formula对应一个Substance"""

    formula: Formula
    chemical_energy: float = 0.0  # J/mol

    name: str | None = None

    @property
    def charge(self):
        return self.formula.valence

    @property
    def relative_mass(self):
        return self.formula.relative_mass

    def __repr__(self):
        if self.name is None:
            return f"Substance({id(self)})"
        return self.name

    def __eq__(self, other):
        if not isinstance(other, Substance):
            return False
        return self.formula == other.formula
