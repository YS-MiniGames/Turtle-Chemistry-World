from dataclasses import dataclass, field

from .phase import PhaseSubstance
from .constant import (
    LIQUID_SURFACE_AREA_MULTIPLIER,
    ENVIRONMENT_TEMPERATURE,
    HEAT_TRANSFER_CONSTANT,
    ENVIRONMENT_HEAT_TRANSFER_COEFFICIENT,
)


@dataclass(eq=False)
class Matter:
    psubstance: PhaseSubstance
    amount: float  # mol
    _internal_energy: float | None = None
    _surface_area: float | None = None
    internal_energy: float = field(init=False)  # J
    surface_area: float = field(init=False)  # m**2

    def __post_init__(self):
        if self._internal_energy is not None:
            self.internal_energy = self._internal_energy
        else:
            self.internal_energy = (
                self.psubstance.specific_heat * self.amount * ENVIRONMENT_TEMPERATURE
            )

        if self._surface_area is not None:
            self.surface_area = self._surface_area
        else:
            self.surface_area = (
                self.size**2 * self.psubstance.surface_area_multiplier
            )

    @property
    def substance(self):
        return self.psubstance.substance

    @property
    def phase(self):
        return self.psubstance.phase

    @property
    def density(self):
        return self.psubstance.density

    @property
    def specific_heat(self):
        return self.psubstance.specific_heat

    @property
    def heat_transfer_coefficient(self):
        return self.psubstance.heat_transfer_coefficient

    @property
    def relative_mass(self):
        return self.psubstance.relative_mass

    @property
    def chemical_energy(self):
        return self.psubstance.chemical_energy * self.amount

    @property
    def phase_energy(self):
        return self.psubstance.phase_energy * self.amount

    @property
    def energy(self):
        return self.chemical_energy + self.phase_energy + self.internal_energy

    @property
    def temperature(self):
        return self.internal_energy / (self.psubstance.specific_heat * self.amount)

    @property
    def mass(self):
        return self.amount * self.relative_mass

    @property
    def volume(self):
        return self.mass / self.density

    @property
    def size(self) -> float:  # cm
        return self.volume ** (1 / 3)

    def reset_liquid_surface_area(
        self, surface_area_multiplier: float = LIQUID_SURFACE_AREA_MULTIPLIER
    ):
        self.surface_area = self.size**2 * surface_area_multiplier

    def add_matter(self, other: "Matter"):
        self.amount += other.amount
        self.internal_energy += other.internal_energy

    def add_heat(self, heat: float):
        self.internal_energy += heat

    def transfer_heat(self, other: "Matter") -> float:
        delta_temperature = other.temperature - self.temperature
        heat_transfer_coefficient = (
            self.heat_transfer_coefficient * other.heat_transfer_coefficient
        ) ** 0.5
        surface_area = min(self.surface_area, other.surface_area)
        return (
            delta_temperature
            * heat_transfer_coefficient
            * surface_area
            * HEAT_TRANSFER_CONSTANT
        )

    def transfer_heat_environment(
        self, environment_temperature: float = ENVIRONMENT_TEMPERATURE
    ) -> float:
        delta_temperature = environment_temperature - self.temperature
        heat_transfer_coefficient = (
            self.heat_transfer_coefficient * ENVIRONMENT_HEAT_TRANSFER_COEFFICIENT
        ) ** 0.5
        surface_area = self.surface_area
        return (
            delta_temperature
            * heat_transfer_coefficient
            * surface_area
            * HEAT_TRANSFER_CONSTANT
        )
